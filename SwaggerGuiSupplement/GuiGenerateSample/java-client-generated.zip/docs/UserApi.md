# UserApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**deleteUser**](UserApi.md#deleteUser) | **DELETE** /user/{username} | ユーザ削除
[**getUserByName**](UserApi.md#getUserByName) | **GET** /user/{username} | ユーザ参照API
[**updateUser**](UserApi.md#updateUser) | **PUT** /user/{username} | ユーザ名更新

<a name="deleteUser"></a>
# **deleteUser**
> deleteUser(username)

ユーザ削除

ユーザ削除

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UserApi;


UserApi apiInstance = new UserApi();
String username = "username_example"; // String | 削除対象ユーザ名
try {
    apiInstance.deleteUser(username);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#deleteUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**| 削除対象ユーザ名 |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="getUserByName"></a>
# **getUserByName**
> User getUserByName(username)

ユーザ参照API

ユーザ名検索

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UserApi;


UserApi apiInstance = new UserApi();
String username = "username_example"; // String | 
try {
    User result = apiInstance.getUserByName(username);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#getUserByName");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**|  |

### Return type

[**User**](User.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

<a name="updateUser"></a>
# **updateUser**
> updateUser(username, body)

ユーザ名更新

ユーザ名更新処理

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UserApi;


UserApi apiInstance = new UserApi();
String username = "username_example"; // String | name that need to be deleted
User body = new User(); // User | ユーザ名更新結果
try {
    apiInstance.updateUser(username, body);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#updateUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**| name that need to be deleted |
 **body** | [**User**](User.md)| ユーザ名更新結果 | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json

<a name="updateUser"></a>
# **updateUser**
> updateUser(username, id, username2, firstName, lastName, email, password, phone, userStatus)

ユーザ名更新

ユーザ名更新処理

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.UserApi;


UserApi apiInstance = new UserApi();
String username = "username_example"; // String | name that need to be deleted
Long id = 789L; // Long | 
String username2 = "username_example"; // String | 
String firstName = "firstName_example"; // String | 
String lastName = "lastName_example"; // String | 
String email = "email_example"; // String | 
String password = "password_example"; // String | 
String phone = "phone_example"; // String | 
Integer userStatus = 56; // Integer | 
try {
    apiInstance.updateUser(username, id, username2, firstName, lastName, email, password, phone, userStatus);
} catch (ApiException e) {
    System.err.println("Exception when calling UserApi#updateUser");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **username** | **String**| name that need to be deleted |
 **id** | **Long**|  | [optional]
 **username2** | **String**|  | [optional]
 **firstName** | **String**|  | [optional]
 **lastName** | **String**|  | [optional]
 **email** | **String**|  | [optional]
 **password** | **String**|  | [optional]
 **phone** | **String**|  | [optional]
 **userStatus** | **Integer**|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml, application/x-www-form-urlencoded
 - **Accept**: application/json

